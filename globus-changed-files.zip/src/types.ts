export type ListingType = 'service' | 'item' | 'time';

export type Category = 
  | 'education' 
  | 'tech' 
  | 'repairs' 
  | 'creative' 
  | 'gear' 
  | 'home' 
  | 'transport' 
  | 'wellness';

export interface User {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  role: string;
  bio: string;
  activeTokens: number;      // Токены, готовые к тратам
  pendingTokens: number;     // Токены в ожидании активации (от предложенных услуг)
  completedDealsCount: number;
  providedServicesCount: number;
  rating: number;
  location: string;
}

export type DeliveryMethod = 'pickup' | 'courier' | 'post' | 'meeting' | 'digital' | 'other';

export interface MediaItem {
  id: string;
  kind: 'image' | 'video';
  name: string;
  src?: string; // Для фото: сжатое изображение (data URL). Видео хранится в IndexedDB по id.
}

export interface Listing {
  id: string;
  title: string;
  description: string;
  type: ListingType;
  category: Category;
  priceGlo: number;           // Стоимость в токенах GLO (1 GLO ≈ 1 час полезного действия)
  durationUnit: string;       // "час", "сутки", "консультация", "задание"
  providerId: string;
  providerName: string;
  providerAvatar: string;
  providerRating: number;
  providerRole: string;
  location: string;
  isOnline: boolean;
  usageCount: number;
  status: 'available' | 'in_use' | 'paused';
  createdAt: string;
  tags: string[];
  media?: MediaItem[];            // Фото и видео товара
  deliveryMethod?: DeliveryMethod; // Способ доставки / передачи
  deliveryUrl?: string;            // Ссылка на способ доставки
}

export type DealStatus = 'requested' | 'in_progress' | 'completed' | 'cancelled';

export interface Deal {
  id: string;
  listingId: string;
  listingTitle: string;
  listingType: ListingType;
  priceGlo: number;
  buyerId: string;
  buyerName: string;
  buyerAvatar: string;
  sellerId: string;
  sellerName: string;
  sellerAvatar: string;
  status: DealStatus;
  requestedDate: string;
  completedDate?: string;
  note?: string;
  tokensActivated: boolean; // Стали ли токены активными у продавца
}

export interface TokenTransaction {
  id: string;
  userId: string;
  amount: number;
  type: 'activation' | 'escrow_hold' | 'received_active' | 'spent' | 'welcome';
  title: string;
  description: string;
  timestamp: string;
  dealId?: string;
  isActive: boolean;
}

export interface Review {
  id: string;
  dealId?: string;
  listingId?: string;
  listingTitle?: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  targetUserId: string; // Пользователь, которому оставлен отзыв
  rating: number;       // Оценка от 1 до 5
  comment: string;
  tags: string[];       // Теги доверия (например: 'Пунктуальность', 'Мастер своего дела')
  createdAt: string;
  role: 'client' | 'provider'; // Роль автора в сделке
}

export interface UserTrustStats {
  averageRating: number;
  totalReviews: number;
  fiveStarCount: number;
  fourStarCount: number;
  threeStarCount: number;
  twoStarCount: number;
  oneStarCount: number;
  positivePercentage: number;
  topTags: { tag: string; count: number }[];
  isVerified: boolean;
  dealsCount: number;
}

