import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Listing, Deal, TokenTransaction, ListingType, Category, Review, UserTrustStats, MediaItem, DeliveryMethod } from '../types';
import { INITIAL_USERS, INITIAL_LISTINGS, INITIAL_DEALS, INITIAL_TRANSACTIONS, INITIAL_REVIEWS } from '../data/mockData';

interface ActivationNotice {
  deal: Deal;
  amount: number;
  providerName: string;
  clientName: string;
  itemOrServiceTitle: string;
}

interface GlobusContextType {
  currentUser: User;
  users: User[];
  listings: Listing[];
  deals: Deal[];
  transactions: TokenTransaction[];
  reviews: Review[];
  activeTab: 'market' | 'deals' | 'my-listings' | 'wallet' | 'how-it-works';
  activationNotice: ActivationNotice | null;
  selectedUserProfile: User | null;
  reviewingDeal: Deal | null;
  setActiveTab: (tab: 'market' | 'deals' | 'my-listings' | 'wallet' | 'how-it-works') => void;
  switchUser: (userId: string) => void;
  openUserProfile: (userOrId: User | string) => void;
  closeUserProfile: () => void;
  openReviewModal: (deal: Deal) => void;
  closeReviewModal: () => void;
  addReview: (reviewData: {
    targetUserId: string;
    dealId?: string;
    listingId?: string;
    listingTitle?: string;
    rating: number;
    comment: string;
    tags: string[];
    role?: 'client' | 'provider';
  }) => void;
  getUserReviews: (userId: string) => Review[];
  getUserTrustStats: (userId: string) => UserTrustStats;
  hasUserReviewedDeal: (dealId: string, authorId: string) => boolean;
  createListing: (data: {
    title: string;
    description: string;
    type: ListingType;
    category: Category;
    priceGlo: number;
    durationUnit: string;
    location: string;
    isOnline: boolean;
    tags: string[];
    media?: MediaItem[];
    deliveryMethod?: DeliveryMethod;
    deliveryUrl?: string;
  }) => void;
  requestDeal: (listingId: string, note?: string) => { success: boolean; message: string };
  confirmDealCompletion: (dealId: string) => void;
  acceptDeal: (dealId: string) => void;
  dismissActivationNotice: () => void;
  addFreeTokensForTesting: (amount: number) => void;
  resetToDefault: () => void;
}

const GlobusContext = createContext<GlobusContextType | undefined>(undefined);

const STORAGE_KEY_PREFIX = 'globus_app_data_v3';

export const GlobusProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}_users`);
    return saved ? JSON.parse(saved) : INITIAL_USERS;
  });

  const [currentUserId, setCurrentUserId] = useState<string>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}_current_user`);
    return saved || 'user-1';
  });

  const [listings, setListings] = useState<Listing[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}_listings`);
    return saved ? JSON.parse(saved) : INITIAL_LISTINGS;
  });

  const [deals, setDeals] = useState<Deal[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}_deals`);
    return saved ? JSON.parse(saved) : INITIAL_DEALS;
  });

  const [transactions, setTransactions] = useState<TokenTransaction[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}_transactions`);
    return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
  });

  const [reviews, setReviews] = useState<Review[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}_reviews`);
    return saved ? JSON.parse(saved) : INITIAL_REVIEWS;
  });

  const [activeTab, setActiveTab] = useState<'market' | 'deals' | 'my-listings' | 'wallet' | 'how-it-works'>('market');
  const [activationNotice, setActivationNotice] = useState<ActivationNotice | null>(null);
  const [selectedUserProfile, setSelectedUserProfile] = useState<User | null>(null);
  const [reviewingDeal, setReviewingDeal] = useState<Deal | null>(null);

  // Sync state to local storage
  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}_users`, JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}_current_user`, currentUserId);
  }, [currentUserId]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY_PREFIX}_listings`, JSON.stringify(listings));
    } catch (e) {
      // Переполнение localStorage из-за фото: сохраняем объявления без встроенных изображений
      console.warn('Не удалось сохранить объявления с фото, сохраняем без медиа', e);
      try {
        localStorage.setItem(
          `${STORAGE_KEY_PREFIX}_listings`,
          JSON.stringify(listings.map(l => ({ ...l, media: undefined })))
        );
      } catch {
        // ничего не делаем
      }
    }
  }, [listings]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}_deals`, JSON.stringify(deals));
  }, [deals]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}_transactions`, JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}_reviews`, JSON.stringify(reviews));
  }, [reviews]);

  const currentUser = users.find(u => u.id === currentUserId) || users[0];

  const switchUser = (userId: string) => {
    setCurrentUserId(userId);
  };

  const openUserProfile = (userOrId: User | string) => {
    if (typeof userOrId === 'string') {
      const found = users.find(u => u.id === userOrId);
      if (found) setSelectedUserProfile(found);
    } else {
      setSelectedUserProfile(userOrId);
    }
  };

  const closeUserProfile = () => {
    setSelectedUserProfile(null);
  };

  const openReviewModal = (deal: Deal) => {
    setReviewingDeal(deal);
  };

  const closeReviewModal = () => {
    setReviewingDeal(null);
  };

  const getUserReviews = (userId: string): Review[] => {
    return reviews.filter(r => r.targetUserId === userId);
  };

  const hasUserReviewedDeal = (dealId: string, authorId: string): boolean => {
    return reviews.some(r => r.dealId === dealId && r.authorId === authorId);
  };

  const getUserTrustStats = (userId: string): UserTrustStats => {
    const user = users.find(u => u.id === userId);
    const userReviews = reviews.filter(r => r.targetUserId === userId);
    
    const totalReviews = userReviews.length;
    const averageRating = totalReviews > 0
      ? Math.round((userReviews.reduce((sum, r) => sum + r.rating, 0) / totalReviews) * 10) / 10
      : (user?.rating || 5.0);

    const fiveStarCount = userReviews.filter(r => r.rating === 5).length;
    const fourStarCount = userReviews.filter(r => r.rating === 4).length;
    const threeStarCount = userReviews.filter(r => r.rating === 3).length;
    const twoStarCount = userReviews.filter(r => r.rating === 2).length;
    const oneStarCount = userReviews.filter(r => r.rating === 1).length;

    const positiveCount = fiveStarCount + fourStarCount;
    const positivePercentage = totalReviews > 0 ? Math.round((positiveCount / totalReviews) * 100) : 100;

    // Aggregate tags
    const tagCounts: Record<string, number> = {};
    userReviews.forEach(r => {
      r.tags?.forEach(t => {
        tagCounts[t] = (tagCounts[t] || 0) + 1;
      });
    });

    const topTags = Object.entries(tagCounts)
      .map(([tag, count]) => ({ tag, count }))
      .sort((a, b) => b.count - a.count);

    const completedDeals = deals.filter(
      d => (d.sellerId === userId || d.buyerId === userId) && d.status === 'completed'
    ).length;

    return {
      averageRating,
      totalReviews,
      fiveStarCount,
      fourStarCount,
      threeStarCount,
      twoStarCount,
      oneStarCount,
      positivePercentage,
      topTags,
      isVerified: completedDeals >= 1 || (user?.completedDealsCount || 0) >= 1,
      dealsCount: Math.max(completedDeals, user?.completedDealsCount || 0),
    };
  };

  const addReview = (reviewData: {
    targetUserId: string;
    dealId?: string;
    listingId?: string;
    listingTitle?: string;
    rating: number;
    comment: string;
    tags: string[];
    role?: 'client' | 'provider';
  }) => {
    const newReview: Review = {
      id: `rev-${Date.now()}`,
      dealId: reviewData.dealId,
      listingId: reviewData.listingId,
      listingTitle: reviewData.listingTitle,
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorAvatar: currentUser.avatar,
      targetUserId: reviewData.targetUserId,
      rating: reviewData.rating,
      comment: reviewData.comment,
      tags: reviewData.tags,
      createdAt: 'Сегодня',
      role: reviewData.role || 'client',
    };

    const updatedReviews = [newReview, ...reviews];
    setReviews(updatedReviews);

    // Recalculate target user's rating
    const targetUserReviews = updatedReviews.filter(r => r.targetUserId === reviewData.targetUserId);
    const newAvgRating = Math.round(
      (targetUserReviews.reduce((sum, r) => sum + r.rating, 0) / targetUserReviews.length) * 10
    ) / 10;

    setUsers(prev => prev.map(u => {
      if (u.id === reviewData.targetUserId) {
        return { ...u, rating: newAvgRating };
      }
      return u;
    }));

    // Update listing providerRating
    setListings(prev => prev.map(l => {
      if (l.providerId === reviewData.targetUserId) {
        return { ...l, providerRating: newAvgRating };
      }
      return l;
    }));

    // If viewing this profile, update it too
    if (selectedUserProfile && selectedUserProfile.id === reviewData.targetUserId) {
      setSelectedUserProfile(prev => prev ? { ...prev, rating: newAvgRating } : null);
    }
  };


  const createListing = (data: {
    title: string;
    description: string;
    type: ListingType;
    category: Category;
    priceGlo: number;
    durationUnit: string;
    location: string;
    isOnline: boolean;
    tags: string[];
    media?: MediaItem[];
    deliveryMethod?: DeliveryMethod;
    deliveryUrl?: string;
  }) => {
    const newListing: Listing = {
      id: `list-${Date.now()}`,
      title: data.title,
      description: data.description,
      type: data.type,
      category: data.category,
      priceGlo: Number(data.priceGlo) || 1,
      durationUnit: data.durationUnit || 'услуга',
      providerId: currentUser.id,
      providerName: currentUser.name,
      providerAvatar: currentUser.avatar,
      providerRating: currentUser.rating,
      providerRole: currentUser.role,
      location: data.location || (data.isOnline ? 'Онлайн' : currentUser.location),
      isOnline: data.isOnline,
      usageCount: 0,
      status: 'available',
      createdAt: new Date().toISOString().split('T')[0],
      tags: data.tags.length > 0 ? data.tags : ['Обмен'],
      media: data.media && data.media.length > 0 ? data.media : undefined,
      deliveryMethod: data.deliveryMethod,
      deliveryUrl: data.deliveryUrl || undefined
    };

    setListings(prev => [newListing, ...prev]);

    // Note: When listing is created, potential tokens are pending upon someone using it!
  };

  const requestDeal = (listingId: string, note?: string): { success: boolean; message: string } => {
    const targetListing = listings.find(l => l.id === listingId);
    if (!targetListing) return { success: false, message: 'Объявление не найдено' };

    if (targetListing.providerId === currentUser.id) {
      return { success: false, message: 'Вы не можете заказать собственную услугу или вещь!' };
    }

    if (currentUser.activeTokens < targetListing.priceGlo) {
      return { 
        success: false, 
        message: `У вас недостаточно активных GLO токенов (${currentUser.activeTokens} из ${targetListing.priceGlo}). Окажите услугу или одолжите вещь, чтобы активировать токены!` 
      };
    }

    const seller = users.find(u => u.id === targetListing.providerId);
    if (!seller) return { success: false, message: 'Владелец услуги не найден' };

    const newDealId = `deal-${Date.now()}`;
    const newDeal: Deal = {
      id: newDealId,
      listingId: targetListing.id,
      listingTitle: targetListing.title,
      listingType: targetListing.type,
      priceGlo: targetListing.priceGlo,
      buyerId: currentUser.id,
      buyerName: currentUser.name,
      buyerAvatar: currentUser.avatar,
      sellerId: seller.id,
      sellerName: seller.name,
      sellerAvatar: seller.avatar,
      status: 'in_progress', // Starts active deal
      requestedDate: new Date().toISOString().split('T')[0],
      note: note || `Запрос на: ${targetListing.title}`,
      tokensActivated: false,
    };

    // Deduct active tokens from buyer and hold them
    setUsers(prev => prev.map(u => {
      if (u.id === currentUser.id) {
        return {
          ...u,
          activeTokens: u.activeTokens - targetListing.priceGlo,
        };
      }
      if (u.id === seller.id) {
        // Seller gets pending tokens that will activate when buyer confirms usage!
        return {
          ...u,
          pendingTokens: u.pendingTokens + targetListing.priceGlo,
        };
      }
      return u;
    }));

    // Add deal to deals list
    setDeals(prev => [newDeal, ...prev]);

    // Update listing usage count
    setListings(prev => prev.map(l => {
      if (l.id === targetListing.id) {
        return { ...l, usageCount: l.usageCount + 1 };
      }
      return l;
    }));

    // Record transactions
    const buyerTx: TokenTransaction = {
      id: `tx-${Date.now()}-buyer`,
      userId: currentUser.id,
      amount: -targetListing.priceGlo,
      type: 'spent',
      title: `Заказ: ${targetListing.title}`,
      description: `Токены зарезервированы для сделки с ${seller.name}`,
      timestamp: new Date().toLocaleString('ru-RU', { dateStyle: 'short', timeStyle: 'short' }),
      dealId: newDealId,
      isActive: true,
    };

    const sellerTx: TokenTransaction = {
      id: `tx-${Date.now()}-seller`,
      userId: seller.id,
      amount: targetListing.priceGlo,
      type: 'escrow_hold',
      title: `Ожидает активации: ${targetListing.title}`,
      description: `${currentUser.name} воспользовался вашей услугой/вещью. Токены станут активными после подтверждения!`,
      timestamp: new Date().toLocaleString('ru-RU', { dateStyle: 'short', timeStyle: 'short' }),
      dealId: newDealId,
      isActive: false,
    };

    setTransactions(prev => [buyerTx, sellerTx, ...prev]);

    return { 
      success: true, 
      message: `Запрос успешно отправлен! ${targetListing.priceGlo} GLO зарезервированы до завершения.` 
    };
  };

  const acceptDeal = (dealId: string) => {
    setDeals(prev => prev.map(d => {
      if (d.id === dealId) {
        return { ...d, status: 'in_progress' };
      }
      return d;
    }));
  };

  // THE KEY MECHANIC: When someone used the service/item and it is completed,
  // the provider's pending tokens ACTIVATE into their active balance!
  const confirmDealCompletion = (dealId: string) => {
    const deal = deals.find(d => d.id === dealId);
    if (!deal || deal.status === 'completed') return;

    const completedDate = new Date().toISOString().split('T')[0];

    // Mark deal as completed and tokens activated
    setDeals(prev => prev.map(d => {
      if (d.id === dealId) {
        return {
          ...d,
          status: 'completed',
          completedDate,
          tokensActivated: true,
        };
      }
      return d;
    }));

    // Seller's pending tokens become ACTIVE!
    setUsers(prev => prev.map(u => {
      if (u.id === deal.sellerId) {
        return {
          ...u,
          pendingTokens: Math.max(0, u.pendingTokens - deal.priceGlo),
          activeTokens: u.activeTokens + deal.priceGlo,
          completedDealsCount: u.completedDealsCount + 1,
          providedServicesCount: u.providedServicesCount + 1,
        };
      }
      if (u.id === deal.buyerId) {
        return {
          ...u,
          completedDealsCount: u.completedDealsCount + 1,
        };
      }
      return u;
    }));

    // Record activation transaction
    const activationTx: TokenTransaction = {
      id: `tx-${Date.now()}-activation`,
      userId: deal.sellerId,
      amount: deal.priceGlo,
      type: 'activation',
      title: 'Токены активированы!',
      description: `${deal.buyerName} подтвердил(а) использование "${deal.listingTitle}". ${deal.priceGlo} GLO переведены в активный баланс!`,
      timestamp: new Date().toLocaleString('ru-RU', { dateStyle: 'short', timeStyle: 'short' }),
      dealId: deal.id,
      isActive: true,
    };

    setTransactions(prev => [activationTx, ...prev]);

    // Show celebratory activation notice
    setActivationNotice({
      deal,
      amount: deal.priceGlo,
      providerName: deal.sellerName,
      clientName: deal.buyerName,
      itemOrServiceTitle: deal.listingTitle,
    });
  };

  const dismissActivationNotice = () => {
    setActivationNotice(null);
  };

  const addFreeTokensForTesting = (amount: number) => {
    setUsers(prev => prev.map(u => {
      if (u.id === currentUser.id) {
        return { ...u, activeTokens: u.activeTokens + amount };
      }
      return u;
    }));

    const bonusTx: TokenTransaction = {
      id: `tx-${Date.now()}-bonus`,
      userId: currentUser.id,
      amount: amount,
      type: 'welcome',
      title: 'Пополнение баланса времени',
      description: 'Тестовое начисление активных токенов GLO',
      timestamp: new Date().toLocaleString('ru-RU', { dateStyle: 'short', timeStyle: 'short' }),
      isActive: true,
    };

    setTransactions(prev => [bonusTx, ...prev]);
  };

  const resetToDefault = () => {
    localStorage.removeItem(`${STORAGE_KEY_PREFIX}_users`);
    localStorage.removeItem(`${STORAGE_KEY_PREFIX}_current_user`);
    localStorage.removeItem(`${STORAGE_KEY_PREFIX}_listings`);
    localStorage.removeItem(`${STORAGE_KEY_PREFIX}_deals`);
    localStorage.removeItem(`${STORAGE_KEY_PREFIX}_transactions`);
    localStorage.removeItem(`${STORAGE_KEY_PREFIX}_reviews`);
    setUsers(INITIAL_USERS);
    setCurrentUserId('user-1');
    setListings(INITIAL_LISTINGS);
    setDeals(INITIAL_DEALS);
    setTransactions(INITIAL_TRANSACTIONS);
    setReviews(INITIAL_REVIEWS);
    setSelectedUserProfile(null);
    setReviewingDeal(null);
    setActiveTab('market');
  };

  return (
    <GlobusContext.Provider
      value={{
        currentUser,
        users,
        listings,
        deals,
        transactions,
        reviews,
        activeTab,
        activationNotice,
        selectedUserProfile,
        reviewingDeal,
        setActiveTab,
        switchUser,
        openUserProfile,
        closeUserProfile,
        openReviewModal,
        closeReviewModal,
        addReview,
        getUserReviews,
        getUserTrustStats,
        hasUserReviewedDeal,
        createListing,
        requestDeal,
        confirmDealCompletion,
        acceptDeal,
        dismissActivationNotice,
        addFreeTokensForTesting,
        resetToDefault,
      }}
    >
      {children}
    </GlobusContext.Provider>
  );
};

export const useGlobus = () => {
  const context = useContext(GlobusContext);
  if (!context) {
    throw new Error('useGlobus must be used within a GlobusProvider');
  }
  return context;
};
