import React, { useState } from 'react';
import { 
  X, 
  Sparkles, 
  MapPin, 
  CheckCircle2, 
  ShieldCheck, 
  Clock, 
  ArrowRight, 
  AlertCircle,
  Wrench,
  BookOpen,
  Camera,
  Laptop,
  Star,
  MessageSquare,
  Award,
  Truck,
  ExternalLink
} from 'lucide-react';
import { Listing } from '../types';
import { useGlobus } from '../context/GlobusContext';
import { ListingGallery } from './ListingMedia';
import { DELIVERY_LABELS, normalizeUrl } from '../utils/media';

interface ListingDetailModalProps {
  listing: Listing | null;
  onClose: () => void;
}

export const ListingDetailModal: React.FC<ListingDetailModalProps> = ({ listing, onClose }) => {
  const { currentUser, requestDeal, setActiveTab, getUserReviews, getUserTrustStats, openUserProfile } = useGlobus();
  const [note, setNote] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!listing) return null;

  const isMyListing = listing.providerId === currentUser.id;
  const hasEnoughTokens = currentUser.activeTokens >= listing.priceGlo;
  const providerReviews = getUserReviews(listing.providerId);
  const trustStats = getUserTrustStats(listing.providerId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const result = requestDeal(listing.id, note);
    if (!result.success) {
      setErrorMsg(result.message);
    } else {
      setSuccessMsg(result.message);
      setTimeout(() => {
        onClose();
        setActiveTab('deals');
      }, 1400);
    }
  };

  const getTypeBadge = () => {
    switch (listing.type) {
      case 'item':
        return { label: 'Вещь / Инструмент', bg: 'bg-amber-50 text-amber-700 border-amber-200' };
      case 'service':
        return { label: 'Услуга мастера / Специалиста', bg: 'bg-teal-50 text-teal-700 border-teal-200' };
      case 'time':
        return { label: 'Время / Консультация', bg: 'bg-indigo-50 text-indigo-700 border-indigo-200' };
      default:
        return { label: 'Предложение', bg: 'bg-slate-50 text-slate-700 border-slate-200' };
    }
  };

  const badge = getTypeBadge();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        id="listing-detail-modal"
        className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-100 bg-slate-50/70">
          <div className="flex items-center gap-2">
            <span className={`text-xs font-semibold px-2.5 py-1 rounded-full border ${badge.bg}`}>
              {badge.label}
            </span>
            <span className="text-xs text-slate-500 font-medium">
              {listing.usageCount} раз воспользовались
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Title & Price */}
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
            <div>
              <h2 className="text-xl font-bold text-slate-900 leading-snug font-['Space_Grotesk']">
                {listing.title}
              </h2>
              <div className="flex items-center gap-3 mt-2 text-xs text-slate-500">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  {listing.location}
                </span>
                <span>•</span>
                <span>Единица: 1 {listing.durationUnit}</span>
              </div>
            </div>

            <div className="shrink-0 bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-right">
              <span className="text-xs font-medium text-emerald-800 block">Стоимость обмена</span>
              <div className="flex items-baseline gap-1 justify-end">
                <span className="text-2xl font-black text-emerald-700 font-['Space_Grotesk']">
                  {listing.priceGlo}
                </span>
                <span className="text-sm font-bold text-emerald-800">GLO</span>
              </div>
              <span className="text-[10px] text-emerald-600 block">за 1 {listing.durationUnit}</span>
            </div>
          </div>

          {/* Photos & Video */}
          <ListingGallery media={listing.media} />

          {/* Delivery */}
          {(listing.deliveryMethod || listing.deliveryUrl) && (
            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-teal-50 border border-teal-200 flex items-center justify-center shrink-0">
                  <Truck className="w-5 h-5 text-teal-700" />
                </div>
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                    Способ доставки
                  </span>
                  <span className="text-sm font-bold text-slate-900">
                    {listing.deliveryMethod ? DELIVERY_LABELS[listing.deliveryMethod] : 'По договорённости'}
                  </span>
                </div>
              </div>
              {listing.deliveryUrl && normalizeUrl(listing.deliveryUrl) && (
                <a
                  href={normalizeUrl(listing.deliveryUrl)!}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-1.5 text-xs font-bold px-3 py-2 rounded-xl bg-white hover:bg-slate-100 text-teal-700 border border-teal-200 shadow-2xs transition-colors"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Открыть ссылку</span>
                </a>
              )}
            </div>
          )}

          {/* Provider Card with Trust Badge & Profile Link */}
          <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <img
                src={listing.providerAvatar}
                alt={listing.providerName}
                className="w-12 h-12 rounded-xl object-cover ring-2 ring-slate-200 shrink-0"
              />
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h4 className="font-bold text-sm text-slate-900">{listing.providerName}</h4>
                  <span className="inline-flex items-center gap-1 text-xs font-bold px-2 py-0.5 rounded-lg bg-amber-50 text-amber-900 border border-amber-200">
                    <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                    <span>{trustStats.averageRating.toFixed(1)}</span>
                  </span>
                  <span className="text-[11px] text-slate-500">
                    ({providerReviews.length} {providerReviews.length === 1 ? 'отзыв' : 'отзывов'})
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">{listing.providerRole}</p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {isMyListing ? (
                <span className="text-xs font-bold text-teal-700 bg-teal-50 px-3 py-1 rounded-full border border-teal-200">
                  Ваше объявление
                </span>
              ) : (
                <button
                  type="button"
                  onClick={() => openUserProfile(listing.providerId)}
                  className="text-xs font-bold px-3 py-1.5 rounded-xl bg-white hover:bg-slate-100 text-teal-700 border border-teal-200 shadow-2xs transition-colors flex items-center gap-1"
                >
                  <Award className="w-3.5 h-3.5 text-teal-600" />
                  <span>Репутация и профиль</span>
                </button>
              )}
            </div>
          </div>

          {/* Description */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Описание услуги или вещи
            </h3>
            <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-line bg-white p-4 rounded-xl border border-slate-100 shadow-2xs">
              {listing.description}
            </p>
          </div>

          {/* Tags */}
          <div className="flex flex-wrap gap-1.5">
            {listing.tags.map(tag => (
              <span key={tag} className="text-xs font-medium bg-slate-100 text-slate-600 px-2.5 py-1 rounded-lg">
                #{tag}
              </span>
            ))}
          </div>

          {/* Community Reviews Preview Section */}
          <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-teal-700" />
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Отзывы сообщества об исполнителе ({providerReviews.length})
                </h3>
              </div>
              <button
                type="button"
                onClick={() => openUserProfile(listing.providerId)}
                className="text-[11px] font-bold text-teal-700 hover:text-teal-800 transition-colors"
              >
                Смотреть все →
              </button>
            </div>

            {providerReviews.length === 0 ? (
              <p className="text-xs text-slate-500 py-2">
                У пользователя пока нет опубликованных отзывов. Первые сделки проходят под защитой системы эскроу Globus!
              </p>
            ) : (
              <div className="space-y-2.5">
                {providerReviews.slice(0, 2).map(rev => (
                  <div key={rev.id} className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-2xs space-y-1.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <img
                          src={rev.authorAvatar}
                          alt={rev.authorName}
                          className="w-6 h-6 rounded-full object-cover ring-1 ring-slate-200"
                        />
                        <span className="text-xs font-bold text-slate-900">{rev.authorName}</span>
                        <span className="text-[10px] text-slate-400">{rev.createdAt}</span>
                      </div>
                      <div className="flex items-center gap-0.5 bg-amber-50 px-1.5 py-0.5 rounded text-amber-900 font-bold text-[11px]">
                        <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                        <span>{rev.rating}.0</span>
                      </div>
                    </div>
                    <p className="text-xs text-slate-600 line-clamp-2">
                      «{rev.comment}»
                    </p>
                    {rev.tags && rev.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 pt-0.5">
                        {rev.tags.map(t => (
                          <span key={t} className="text-[10px] bg-teal-50 text-teal-800 px-1.5 py-0.2 rounded font-medium">
                            ✓ {t}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>


          {/* Token Lifecycle explanation inside deal */}
          <div className="bg-gradient-to-r from-teal-50 to-emerald-50 border border-teal-200/80 rounded-xl p-4">
            <div className="flex items-start gap-3">
              <ShieldCheck className="w-5 h-5 text-teal-700 shrink-0 mt-0.5" />
              <div className="text-xs text-teal-900 leading-relaxed">
                <span className="font-bold block mb-1">Как активируются токены в этой сделке:</span>
                Когда вы нажмете «Воспользоваться», с вашего баланса спишется <span className="font-bold">{listing.priceGlo} GLO</span> и 
                заморозится в сделке. У {listing.providerName.split(' ')[0]} токены окажутся 
                в статусе <span className="font-semibold text-amber-700">«Ожидают активации»</span>. 
                Как только услуга будет оказана или вещь возвращена, вы подтверждаете выполнение, и токены мгновенно становятся 
                <span className="font-bold text-emerald-700"> АКТИВНЫМИ</span> у исполнителя!
              </div>
            </div>
          </div>

          {/* Form */}
          {!isMyListing && (
            <form onSubmit={handleSubmit} className="space-y-4 pt-2">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Комментарий к запросу (желаемое время, адрес или пожелания):
                </label>
                <textarea
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Например: Здравствуйте! Хочу взять инструмент в эту субботу на 1 день..."
                  rows={2}
                  className="w-full text-xs p-3 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-teal-500/30 focus:border-teal-600 transition-all resize-none"
                />
              </div>

              {errorMsg && (
                <div className="flex items-center gap-2 p-3 rounded-xl bg-red-50 text-red-700 text-xs border border-red-200">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {successMsg && (
                <div className="flex items-center gap-2 p-3 rounded-xl bg-emerald-50 text-emerald-800 text-xs border border-emerald-200 font-medium">
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
                  <span>{successMsg}</span>
                </div>
              )}

              <div className="flex items-center justify-between pt-2">
                <div className="text-xs text-slate-500">
                  Ваш активный баланс: <span className="font-bold text-slate-900">{currentUser.activeTokens} GLO</span>
                  {!hasEnoughTokens && (
                    <span className="text-red-500 block">Недостаточно активных токенов</span>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={!hasEnoughTokens}
                  className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-sm shadow-xs transition-all ${
                    hasEnoughTokens
                      ? 'bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer'
                      : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  <span>Воспользоваться за {listing.priceGlo} GLO</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          )}

        </div>

      </div>
    </div>
  );
};
