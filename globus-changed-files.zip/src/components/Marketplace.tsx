import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  Sparkles, 
  Clock, 
  MapPin, 
  Wrench, 
  BookOpen, 
  Camera, 
  Laptop, 
  Home, 
  Car, 
  HeartHandshake, 
  Layers,
  ArrowRight,
  TrendingUp,
  Globe2,
  Star
} from 'lucide-react';
import { Listing, ListingType, Category } from '../types';
import { useGlobus } from '../context/GlobusContext';
import { ActivationExplainerBanner } from './ActivationExplainerBanner';
import { ListingThumb } from './ListingMedia';

interface MarketplaceProps {
  onSelectListing: (listing: Listing) => void;
  onOpenCreateModal: () => void;
}

export const Marketplace: React.FC<MarketplaceProps> = ({ onSelectListing, onOpenCreateModal }) => {
  const { listings, currentUser, openUserProfile, getUserReviews, getUserTrustStats } = useGlobus();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories: { id: string; label: string; icon: React.ReactNode }[] = [
    { id: 'all', label: 'Все категории', icon: <Layers className="w-3.5 h-3.5" /> },
    { id: 'education', label: 'Обучение & Языки', icon: <BookOpen className="w-3.5 h-3.5" /> },
    { id: 'tech', label: 'IT & Разработка', icon: <Laptop className="w-3.5 h-3.5" /> },
    { id: 'repairs', label: 'Ремонт & Сервис', icon: <Wrench className="w-3.5 h-3.5" /> },
    { id: 'gear', label: 'Инструмент & Снаряжение', icon: <Wrench className="w-3.5 h-3.5" /> },
    { id: 'creative', label: 'Фото & Дизайн', icon: <Camera className="w-3.5 h-3.5" /> },
  ];

  const filteredListings = useMemo(() => {
    return listings.filter(item => {
      // Search match
      const matchesSearch = 
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.providerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));

      // Type match
      const matchesType = selectedType === 'all' || item.type === selectedType;

      // Category match
      const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;

      return matchesSearch && matchesType && matchesCategory;
    });
  }, [listings, searchQuery, selectedType, selectedCategory]);

  return (
    <div id="marketplace-view" className="space-y-6">
      
      {/* Banner explaining token activation */}
      <ActivationExplainerBanner />

      {/* Hero bar / Search & Filter Section */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4">
        
        <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
          
          {/* Search bar */}
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              id="marketplace-search-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Поиск услуги, инструмента, репетитора или навыка..."
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-700"
              >
                Очистить
              </button>
            )}
          </div>

          {/* Type Selector Pills */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl overflow-x-auto text-xs font-semibold">
            <button
              onClick={() => setSelectedType('all')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                selectedType === 'all'
                  ? 'bg-white text-slate-900 shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Все предложения
            </button>
            <button
              onClick={() => setSelectedType('service')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                selectedType === 'service'
                  ? 'bg-white text-teal-800 shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              🛠 Услуги
            </button>
            <button
              onClick={() => setSelectedType('item')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                selectedType === 'item'
                  ? 'bg-white text-amber-800 shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              📦 Вещи & Инструменты
            </button>
          </div>

        </div>

        {/* Categories scrollable row */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border whitespace-nowrap transition-all ${
                selectedCategory === cat.id
                  ? 'bg-slate-900 text-white border-slate-900 font-semibold shadow-2xs'
                  : 'bg-white text-slate-600 border-slate-200 hover:border-slate-300 hover:bg-slate-50'
              }`}
            >
              {cat.icon}
              <span>{cat.label}</span>
            </button>
          ))}
        </div>

      </div>

      {/* Results Header */}
      <div className="flex items-center justify-between px-1">
        <div className="flex items-center gap-2">
          <span className="text-sm font-bold text-slate-800">
            Найдено предложений: {filteredListings.length}
          </span>
          <span className="text-xs text-slate-400">
            (1 GLO ≈ 1 час пользы)
          </span>
        </div>

        <button
          onClick={onOpenCreateModal}
          className="text-xs font-semibold text-teal-700 hover:text-teal-800 hover:underline"
        >
          + Предложить свою услугу
        </button>
      </div>

      {/* Grid of Listings */}
      {filteredListings.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center max-w-md mx-auto">
          <Globe2 className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="font-bold text-slate-800 text-base">Ничего не найдено</h3>
          <p className="text-xs text-slate-500 mt-1 mb-4">
            Попробуйте изменить запрос или опубликуйте собственное предложение первым!
          </p>
          <button
            onClick={onOpenCreateModal}
            className="bg-teal-600 text-white text-xs font-bold px-4 py-2 rounded-xl hover:bg-teal-700 transition-colors"
          >
            Предложить услугу или вещь
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
          {filteredListings.map(listing => {
            const isMine = listing.providerId === currentUser.id;
            const isItem = listing.type === 'item';
            const providerReviews = getUserReviews(listing.providerId);
            const trustStats = getUserTrustStats(listing.providerId);

            return (
              <div
                key={listing.id}
                id={`listing-card-${listing.id}`}
                onClick={() => onSelectListing(listing)}
                className="group bg-white rounded-2xl border border-slate-200/90 hover:border-teal-400/80 p-5 flex flex-col justify-between transition-all hover:shadow-lg hover:shadow-slate-200/50 cursor-pointer relative"
              >
                <div>
                  {listing.media && listing.media.length > 0 && (
                    <ListingThumb media={listing.media} className="aspect-video w-full rounded-xl mb-3" />
                  )}
                  {/* Top Bar: Type Badge & Price */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <span 
                      className={`text-[11px] font-bold px-2.5 py-1 rounded-full border ${
                        isItem 
                          ? 'bg-amber-50 text-amber-800 border-amber-200/70' 
                          : 'bg-teal-50 text-teal-800 border-teal-200/70'
                      }`}
                    >
                      {isItem ? '📦 Вещь в аренду' : '🛠 Услуга мастера'}
                    </span>

                    <div className="bg-emerald-50 border border-emerald-200/80 px-2.5 py-1 rounded-xl text-right">
                      <span className="text-xs font-black text-emerald-700 font-['Space_Grotesk']">
                        {listing.priceGlo} GLO
                      </span>
                      <span className="text-[10px] text-emerald-600 block leading-tight">
                        / {listing.durationUnit}
                      </span>
                    </div>
                  </div>

                  {/* Title */}
                  <h3 className="font-bold text-slate-900 text-sm sm:text-base leading-snug group-hover:text-teal-700 transition-colors line-clamp-2">
                    {listing.title}
                  </h3>

                  {/* Description */}
                  <p className="text-xs text-slate-500 mt-2 line-clamp-3 leading-relaxed">
                    {listing.description}
                  </p>

                  {/* Location & Tags */}
                  <div className="flex items-center gap-2 mt-3 text-[11px] text-slate-400">
                    <span className="flex items-center gap-1 truncate">
                      <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                      {listing.location}
                    </span>
                    <span>•</span>
                    <span className="text-emerald-700 font-medium">
                      {listing.usageCount} использовали
                    </span>
                  </div>
                </div>

                {/* Footer: Provider info & CTA */}
                <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      openUserProfile(listing.providerId);
                    }}
                    className="flex items-center gap-2 min-w-0 text-left hover:opacity-80 transition-opacity group/prov"
                    title="Посмотреть репутацию и отзывы участника"
                  >
                    <img
                      src={listing.providerAvatar}
                      alt={listing.providerName}
                      className="w-7 h-7 rounded-lg object-cover ring-1 ring-slate-200 shrink-0 group-hover/prov:ring-teal-400"
                    />
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-slate-800 truncate group-hover/prov:text-teal-700">
                        {listing.providerName}
                      </p>
                      <div className="flex items-center gap-1 text-[10px] text-amber-700 font-bold">
                        <Star className="w-2.5 h-2.5 fill-amber-400 text-amber-400" />
                        <span>{trustStats.averageRating.toFixed(1)}</span>
                        <span className="text-slate-400 font-normal">
                          ({providerReviews.length})
                        </span>
                      </div>
                    </div>
                  </button>

                  {isMine ? (
                    <span className="text-[11px] font-bold text-teal-700 bg-teal-50 px-2.5 py-1 rounded-lg">
                      Ваше
                    </span>
                  ) : (
                    <button
                      type="button"
                      className="flex items-center gap-1 text-xs font-bold text-teal-700 group-hover:text-teal-800 group-hover:translate-x-0.5 transition-all bg-teal-50 hover:bg-teal-100 px-3 py-1.5 rounded-xl"
                    >
                      <span>Воспользоваться</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  )}
                </div>

              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
