import React, { useEffect, useState } from 'react';
import { Play, Image as ImageIcon } from 'lucide-react';
import { MediaItem } from '../types';
import { loadVideo } from '../utils/media';

/** Возвращает URL для показа элемента медиа (для видео достаёт файл из IndexedDB). */
export function useMediaUrl(item: MediaItem | undefined): string | null {
  const [url, setUrl] = useState<string | null>(item?.kind === 'image' ? item.src ?? null : null);

  useEffect(() => {
    if (!item) {
      setUrl(null);
      return;
    }
    if (item.kind === 'image') {
      setUrl(item.src ?? null);
      return;
    }

    let revoked = false;
    let objectUrl: string | null = null;
    setUrl(null);
    loadVideo(item.id)
      .then((blob) => {
        if (!blob || revoked) return;
        objectUrl = URL.createObjectURL(blob);
        setUrl(objectUrl);
      })
      .catch(() => setUrl(null));

    return () => {
      revoked = true;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [item?.id, item?.kind, item?.src]);

  return url;
}

/** Миниатюра для карточек (первое фото; если есть только видео — значок видео). */
export const ListingThumb: React.FC<{ media?: MediaItem[]; className?: string }> = ({ media, className = '' }) => {
  const firstImage = media?.find((m) => m.kind === 'image');
  const hasVideo = media?.some((m) => m.kind === 'video');

  if (!media || media.length === 0) return null;

  return (
    <div className={`relative overflow-hidden bg-slate-100 ${className}`}>
      {firstImage?.src ? (
        <img src={firstImage.src} alt="" className="w-full h-full object-cover" loading="lazy" />
      ) : (
        <div className="w-full h-full flex items-center justify-center text-slate-400">
          {hasVideo ? <Play className="w-8 h-8" /> : <ImageIcon className="w-8 h-8" />}
        </div>
      )}
      {media.length > 1 && (
        <span className="absolute bottom-2 right-2 text-[10px] font-bold bg-slate-900/70 text-white px-2 py-0.5 rounded-full">
          {media.length} медиа
        </span>
      )}
      {hasVideo && firstImage && (
        <span className="absolute top-2 left-2 text-[10px] font-bold bg-slate-900/70 text-white px-2 py-0.5 rounded-full flex items-center gap-1">
          <Play className="w-2.5 h-2.5" /> видео
        </span>
      )}
    </div>
  );
};

const MediaView: React.FC<{ item: MediaItem }> = ({ item }) => {
  const url = useMediaUrl(item);
  if (!url) {
    return (
      <div className="w-full h-full flex items-center justify-center text-xs text-slate-400">
        {item.kind === 'video' ? 'Видео недоступно на этом устройстве' : 'Загрузка...'}
      </div>
    );
  }
  return item.kind === 'video' ? (
    <video src={url} controls playsInline preload="metadata" className="w-full h-full object-contain bg-black" />
  ) : (
    <img src={url} alt={item.name} className="w-full h-full object-contain bg-slate-50" />
  );
};

const MiniThumb: React.FC<{ item: MediaItem }> = ({ item }) => {
  if (item.kind === 'image' && item.src) {
    return <img src={item.src} alt="" className="w-full h-full object-cover" />;
  }
  return (
    <div className="w-full h-full flex items-center justify-center bg-slate-800 text-white">
      <Play className="w-5 h-5" />
    </div>
  );
};

/** Галерея фото и видео в карточке товара. */
export const ListingGallery: React.FC<{ media?: MediaItem[] }> = ({ media }) => {
  const [index, setIndex] = useState(0);

  if (!media || media.length === 0) return null;
  const current = media[Math.min(index, media.length - 1)];

  return (
    <div className="space-y-2">
      <div className="aspect-video w-full rounded-2xl overflow-hidden border border-slate-200 bg-slate-50">
        <MediaView key={current.id} item={current} />
      </div>
      {media.length > 1 && (
        <div className="flex gap-2 overflow-x-auto pb-1">
          {media.map((m, i) => (
            <button
              key={m.id}
              type="button"
              onClick={() => setIndex(i)}
              className={`w-16 h-16 shrink-0 rounded-xl overflow-hidden border-2 transition-all ${
                i === index ? 'border-teal-600' : 'border-transparent opacity-70 hover:opacity-100'
              }`}
              aria-label={`Показать ${m.kind === 'video' ? 'видео' : 'фото'} ${i + 1}`}
            >
              <MiniThumb item={m} />
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
