import React, { useRef, useState } from 'react';
import {
  Truck,
  Link2,
  Video,
  Trash2,
  Play,
  X,
  Sparkles, 
  Wrench, 
  BookOpen, 
  Camera, 
  Plus, 
  Clock, 
  MapPin, 
  Globe2, 
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { ListingType, Category, DeliveryMethod, MediaItem } from '../types';
import { useGlobus } from '../context/GlobusContext';
import {
  MAX_MEDIA_FILES,
  MAX_IMAGE_SOURCE_MB,
  MAX_VIDEO_MB,
  DELIVERY_LABELS,
  compressImage,
  saveVideo,
  deleteVideo,
  newMediaId,
  normalizeUrl,
} from '../utils/media';

interface DraftMedia extends MediaItem {
  previewUrl: string;
  file?: File; // только для видео — сохраняется в IndexedDB при публикации
}

interface CreateListingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CreateListingModal: React.FC<CreateListingModalProps> = ({ isOpen, onClose }) => {
  const { createListing, currentUser, setActiveTab } = useGlobus();

  const [type, setType] = useState<ListingType>('service');
  const [category, setCategory] = useState<Category>('tech');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priceGlo, setPriceGlo] = useState<number>(2);
  const [durationUnit, setDurationUnit] = useState('час');
  const [location, setLocation] = useState(currentUser.location);
  const [isOnline, setIsOnline] = useState(true);
  const [tagsInput, setTagsInput] = useState('Обмен, Навык');
  const [error, setError] = useState<string | null>(null);
  const [media, setMedia] = useState<DraftMedia[]>([]);
  const [mediaBusy, setMediaBusy] = useState(false);
  const [deliveryMethod, setDeliveryMethod] = useState<DeliveryMethod>('pickup');
  const [deliveryUrl, setDeliveryUrl] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFilesSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files: File[] = Array.from<File>((e.target.files ?? []) as ArrayLike<File>);
    e.target.value = '';
    if (files.length === 0) return;

    setError(null);
    setMediaBusy(true);
    const added: DraftMedia[] = [];
    const problems: string[] = [];

    for (const file of files) {
      if (media.length + added.length >= MAX_MEDIA_FILES) {
        problems.push(`Максимум ${MAX_MEDIA_FILES} файлов`);
        break;
      }
      const sizeMb = file.size / (1024 * 1024);

      if (file.type.startsWith('image/')) {
        if (sizeMb > MAX_IMAGE_SOURCE_MB) {
          problems.push(`«${file.name}»: фото больше ${MAX_IMAGE_SOURCE_MB} МБ`);
          continue;
        }
        try {
          const src = await compressImage(file);
          added.push({ id: newMediaId(), kind: 'image', name: file.name, src, previewUrl: src });
        } catch {
          problems.push(`«${file.name}»: не удалось обработать фото`);
        }
      } else if (file.type.startsWith('video/')) {
        if (sizeMb > MAX_VIDEO_MB) {
          problems.push(`«${file.name}»: видео больше ${MAX_VIDEO_MB} МБ`);
          continue;
        }
        added.push({
          id: newMediaId(),
          kind: 'video',
          name: file.name,
          previewUrl: URL.createObjectURL(file),
          file,
        });
      } else {
        problems.push(`«${file.name}»: поддерживаются только фото и видео`);
      }
    }

    setMedia(prev => [...prev, ...added]);
    setMediaBusy(false);
    if (problems.length > 0) setError(problems.join('. '));
  };

  const removeMedia = (id: string) => {
    setMedia(prev => {
      const target = prev.find(m => m.id === id);
      if (target?.kind === 'video') URL.revokeObjectURL(target.previewUrl);
      return prev.filter(m => m.id !== id);
    });
  };

  const resetMedia = () => {
    media.forEach(m => {
      if (m.kind === 'video') URL.revokeObjectURL(m.previewUrl);
    });
    setMedia([]);
  };

  const handleClose = () => {
    resetMedia();
    onClose();
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!title.trim()) {
      setError('Пожалуйста, укажите название предложения');
      return;
    }

    if (!description.trim()) {
      setError('Пожалуйста, опишите услугу или вещь');
      return;
    }

    let normalizedDeliveryUrl: string | undefined;
    if (deliveryUrl.trim()) {
      const checked = normalizeUrl(deliveryUrl);
      if (!checked) {
        setError('Ссылка на способ доставки указана неверно. Пример: https://example.com/delivery');
        return;
      }
      normalizedDeliveryUrl = checked;
    }

    const tags = tagsInput
      .split(',')
      .map(t => t.trim())
      .filter(Boolean);

    // Видео сохраняем в IndexedDB, фото уже сжаты и лежат прямо в объявлении
    setMediaBusy(true);
    const savedMedia: MediaItem[] = [];
    const skipped: string[] = [];
    for (const m of media) {
      if (m.kind === 'video' && m.file) {
        try {
          await saveVideo(m.id, m.file);
          savedMedia.push({ id: m.id, kind: 'video', name: m.name });
        } catch {
          skipped.push(m.name);
        }
      } else {
        savedMedia.push({ id: m.id, kind: 'image', name: m.name, src: m.src });
      }
    }
    setMediaBusy(false);

    if (skipped.length > 0) {
      setError(`Не удалось сохранить видео: ${skipped.join(', ')}. Попробуйте файл поменьше.`);
      await Promise.all(savedMedia.filter(m => m.kind === 'video').map(m => deleteVideo(m.id)));
      return;
    }

    createListing({
      title: title.trim(),
      description: description.trim(),
      type,
      category,
      priceGlo: Math.max(1, Number(priceGlo) || 1),
      durationUnit: durationUnit.trim() || 'услуга',
      location: isOnline ? 'Онлайн' : location.trim(),
      isOnline,
      tags,
      media: savedMedia,
      deliveryMethod,
      deliveryUrl: normalizedDeliveryUrl,
    });

    media.forEach(m => {
      if (m.kind === 'video') URL.revokeObjectURL(m.previewUrl);
    });
    setMedia([]);
    setDeliveryUrl('');
    onClose();
    setActiveTab('my-listings');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        id="create-listing-modal"
        className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-100 bg-slate-50/80">
          <div>
            <h2 className="text-lg font-bold text-slate-900 font-['Space_Grotesk']">
              Предложить услугу или вещь в Globus
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Токены активируются, когда другой участник воспользуется вашим предложением!
            </p>
          </div>
          <button
            type="button"
            onClick={handleClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5">
          
          {/* Type of Offer */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-2">
              Тип предложения:
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => {
                  setType('service');
                  setDurationUnit('час');
                }}
                className={`p-3 rounded-xl border text-left transition-all ${
                  type === 'service'
                    ? 'border-teal-600 bg-teal-50/60 text-teal-900 font-bold shadow-2xs'
                    : 'border-slate-200 hover:border-slate-300 text-slate-600'
                }`}
              >
                <span className="text-xs block font-bold">🛠 Услуга</span>
                <span className="text-[11px] text-slate-500 font-normal">Ремонт, урок, помощь</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setType('item');
                  setDurationUnit('сутки');
                  setIsOnline(false);
                }}
                className={`p-3 rounded-xl border text-left transition-all ${
                  type === 'item'
                    ? 'border-amber-600 bg-amber-50/60 text-amber-900 font-bold shadow-2xs'
                    : 'border-slate-200 hover:border-slate-300 text-slate-600'
                }`}
              >
                <span className="text-xs block font-bold">📦 Вещь / Прибор</span>
                <span className="text-[11px] text-slate-500 font-normal">Инструмент, палатка</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setType('time');
                  setDurationUnit('консультация');
                }}
                className={`p-3 rounded-xl border text-left transition-all ${
                  type === 'time'
                    ? 'border-indigo-600 bg-indigo-50/60 text-indigo-900 font-bold shadow-2xs'
                    : 'border-slate-200 hover:border-slate-300 text-slate-600'
                }`}
              >
                <span className="text-xs block font-bold">⏱ Время & Экспертиза</span>
                <span className="text-[11px] text-slate-500 font-normal">Совет, менторство</span>
              </button>
            </div>
          </div>

          {/* Title */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Название предложения:
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Например: Уроки разговорного английского или Перфоратор Makita"
              className="w-full text-xs p-3 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600"
            />
          </div>

          {/* Category */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Категория:
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as Category)}
                className="w-full text-xs p-3 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600 bg-white"
              >
                <option value="tech">IT & Разработка</option>
                <option value="education">Обучение & Языки</option>
                <option value="repairs">Ремонт & Сервис</option>
                <option value="gear">Инструменты & Снаряжение</option>
                <option value="creative">Творчество & Дизайн</option>
                <option value="home">Дом & Сад</option>
                <option value="transport">Транспорт & Велосипеды</option>
                <option value="wellness">Здоровье & Спорт</option>
              </select>
            </div>

            {/* Price & Unit */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Токены (GLO):
                </label>
                <input
                  type="number"
                  min="1"
                  max="50"
                  value={priceGlo}
                  onChange={(e) => setPriceGlo(Number(e.target.value))}
                  className="w-full text-xs p-3 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600 font-bold font-['Space_Grotesk']"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Единица:
                </label>
                <input
                  type="text"
                  value={durationUnit}
                  onChange={(e) => setDurationUnit(e.target.value)}
                  placeholder="час, сутки, проект"
                  className="w-full text-xs p-3 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600"
                />
              </div>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Подробное описание:
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Расскажите о вашем опыте, состоянии вещи, условиях и что получит другой участник..."
              rows={3}
              className="w-full text-xs p-3 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600 resize-none"
            />
          </div>

          {/* Location & Format */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Формат:
              </label>
              <div className="flex items-center gap-3 pt-2">
                <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                  <input
                    type="radio"
                    name="format"
                    checked={isOnline}
                    onChange={() => setIsOnline(true)}
                    className="accent-teal-600"
                  />
                  <span>Онлайн (Zoom/Telegram)</span>
                </label>
                <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                  <input
                    type="radio"
                    name="format"
                    checked={!isOnline}
                    onChange={() => setIsOnline(false)}
                    className="accent-teal-600"
                  />
                  <span>Очно / Локально</span>
                </label>
              </div>
            </div>

            {!isOnline && (
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Город / Район:
                </label>
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="Например: Алматы, Центр"
                  className="w-full text-xs p-3 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600"
                />
              </div>
            )}
          </div>

          {/* Photos & Video */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Фото и видео товара:
            </label>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*,video/*"
              multiple
              onChange={handleFilesSelected}
              className="hidden"
            />

            {media.length > 0 && (
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 mb-2">
                {media.map(m => (
                  <div
                    key={m.id}
                    className="relative aspect-square rounded-xl overflow-hidden border border-slate-200 bg-slate-100"
                  >
                    {m.kind === 'image' ? (
                      <img src={m.previewUrl} alt={m.name} className="w-full h-full object-cover" />
                    ) : (
                      <>
                        <video src={m.previewUrl} muted playsInline className="w-full h-full object-cover" />
                        <span className="absolute inset-0 flex items-center justify-center bg-slate-900/30 text-white">
                          <Play className="w-6 h-6" />
                        </span>
                      </>
                    )}
                    <button
                      type="button"
                      onClick={() => removeMedia(m.id)}
                      className="absolute top-1 right-1 p-1 rounded-lg bg-white/90 text-red-600 hover:bg-white shadow-xs"
                      aria-label={`Удалить ${m.name}`}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={mediaBusy || media.length >= MAX_MEDIA_FILES}
              className="w-full flex items-center justify-center gap-2 text-xs font-semibold p-3 rounded-xl border-2 border-dashed border-slate-300 text-slate-600 hover:border-teal-500 hover:text-teal-700 hover:bg-teal-50/40 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Camera className="w-4 h-4" />
              <Video className="w-4 h-4" />
              <span>
                {mediaBusy
                  ? 'Обработка...'
                  : media.length === 0
                    ? 'Добавить фото или видео'
                    : `Добавить ещё (${media.length}/${MAX_MEDIA_FILES})`}
              </span>
            </button>
            <p className="text-[11px] text-slate-400 mt-1.5">
              До {MAX_MEDIA_FILES} файлов. Фото сжимаются автоматически, видео — до {MAX_VIDEO_MB} МБ.
              Видео хранится в этом браузере.
            </p>
          </div>

          {/* Delivery */}
          <div className="bg-slate-50/70 border border-slate-200 rounded-xl p-4 space-y-3">
            <div className="flex items-center gap-2">
              <Truck className="w-4 h-4 text-teal-700" />
              <span className="text-xs font-bold text-slate-700">Способ доставки</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Как передаётся товар / услуга:
                </label>
                <select
                  value={deliveryMethod}
                  onChange={(e) => setDeliveryMethod(e.target.value as DeliveryMethod)}
                  className="w-full text-xs p-3 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600 bg-white"
                >
                  {(Object.keys(DELIVERY_LABELS) as DeliveryMethod[]).map(key => (
                    <option key={key} value={key}>{DELIVERY_LABELS[key]}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Ссылка на способ доставки (необязательно):
                </label>
                <div className="relative">
                  <Link2 className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    inputMode="url"
                    value={deliveryUrl}
                    onChange={(e) => setDeliveryUrl(e.target.value)}
                    placeholder="https://..."
                    className="w-full text-xs p-3 pl-8 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600 bg-white"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Tags */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Теги через запятую:
            </label>
            <input
              type="text"
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
              placeholder="Языки, Практика, Обучение"
              className="w-full text-xs p-3 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600"
            />
          </div>

          {error && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-red-50 text-red-700 text-xs border border-red-200">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Activation Reminder */}
          <div className="bg-emerald-50 border border-emerald-200/80 rounded-xl p-3.5 flex items-start gap-2.5">
            <Sparkles className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <p className="text-xs text-emerald-950">
              <strong>Напоминание об активации:</strong> После публикации другие пользователи увидят ваше объявление в маркете. 
              Когда кто-то воспользуется им и подтвердит, вы получите <strong className="text-emerald-700">{priceGlo} активных GLO</strong>!
            </p>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={handleClose}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors"
            >
              Отмена
            </button>
            <button
              type="submit"
              disabled={mediaBusy}
              className="bg-teal-600 hover:bg-teal-700 text-white px-5 py-2.5 rounded-xl font-bold text-xs shadow-xs transition-colors disabled:opacity-60"
            >
              {mediaBusy ? 'Сохраняем...' : 'Опубликовать предложение'}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
