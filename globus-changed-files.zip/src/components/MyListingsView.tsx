import React, { useState } from 'react';
import { 
  Layers, 
  Plus, 
  Sparkles, 
  MapPin, 
  Eye, 
  ArrowRight, 
  Clock, 
  CheckCircle2, 
  Check, 
  Handshake,
  Activity,
  AlertCircle
} from 'lucide-react';
import { useGlobus } from '../context/GlobusContext';
import { Listing, Deal } from '../types';
import { ListingThumb } from './ListingMedia';

interface MyListingsViewProps {
  onSelectListing: (listing: Listing) => void;
  onOpenCreateModal: () => void;
}

type StatusFilter = 'all' | 'requested' | 'in_progress' | 'completed' | 'available';

function getDealsDeclension(count: number): string {
  const mod10 = count % 10;
  const mod100 = count % 100;
  if (mod100 >= 11 && mod100 <= 19) return 'сделок';
  if (mod10 === 1) return 'сделка';
  if (mod10 >= 2 && mod10 <= 4) return 'сделки';
  return 'сделок';
}

export const MyListingsView: React.FC<MyListingsViewProps> = ({ onSelectListing, onOpenCreateModal }) => {
  const { listings, currentUser, deals, acceptDeal, confirmDealCompletion, setActiveTab } = useGlobus();
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');

  const myListings = listings.filter(l => l.providerId === currentUser.id);

  // Stats for the provider across all their listings
  const listingsWithRequested = myListings.filter(l => 
    deals.some(d => d.listingId === l.id && d.status === 'requested')
  );
  const listingsWithInProgress = myListings.filter(l => 
    deals.some(d => d.listingId === l.id && d.status === 'in_progress')
  );
  const listingsWithCompleted = myListings.filter(l => 
    deals.some(d => d.listingId === l.id && d.status === 'completed')
  );
  const listingsAvailable = myListings.filter(l => 
    !deals.some(d => d.listingId === l.id && (d.status === 'requested' || d.status === 'in_progress'))
  );

  // Filter listings according to active filter
  const filteredListings = myListings.filter(listing => {
    const listingDeals = deals.filter(d => d.listingId === listing.id);
    if (statusFilter === 'requested') {
      return listingDeals.some(d => d.status === 'requested');
    }
    if (statusFilter === 'in_progress') {
      return listingDeals.some(d => d.status === 'in_progress');
    }
    if (statusFilter === 'completed') {
      return listingDeals.some(d => d.status === 'completed');
    }
    if (statusFilter === 'available') {
      return !listingDeals.some(d => d.status === 'requested' || d.status === 'in_progress');
    }
    return true;
  });

  return (
    <div id="my-listings-view" className="space-y-6">
      
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 font-['Space_Grotesk'] flex items-center gap-2">
            <Layers className="w-5 h-5 text-teal-600" />
            <span>Мои предложения услуг и вещей</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Отслеживайте статусы сделок: в ожидании, в процессе выполнения и успешно завершенные с активацией GLO
          </p>
        </div>

        <button
          onClick={onOpenCreateModal}
          className="flex items-center gap-1.5 bg-teal-600 hover:bg-teal-700 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-xs transition-colors self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>Добавить услугу / вещь</span>
        </button>
      </div>

      {/* Visual Status Indicators Filter Bar */}
      {myListings.length > 0 && (
        <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-2xs flex flex-wrap items-center gap-2">
          <span className="text-xs font-semibold text-slate-500 mr-1 hidden sm:inline">
            Статус сделок:
          </span>

          {/* All */}
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
              statusFilter === 'all'
                ? 'bg-slate-900 text-white shadow-2xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <span>Все</span>
            <span className="text-[11px] opacity-80 px-1.5 py-0.2 rounded-md bg-white/20">
              {myListings.length}
            </span>
          </button>

          {/* Indicator: Waiting / Requested */}
          <button
            onClick={() => setStatusFilter('requested')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
              statusFilter === 'requested'
                ? 'bg-amber-600 text-white shadow-2xs font-bold'
                : 'bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-100'
            }`}
          >
            <Clock className={`w-3.5 h-3.5 ${statusFilter === 'requested' ? 'text-white' : 'text-amber-600'}`} />
            <span>Ожидание</span>
            <span className={`text-[11px] px-1.5 py-0.2 rounded-md font-bold ${
              statusFilter === 'requested' ? 'bg-white/20 text-white' : 'bg-amber-200/70 text-amber-900'
            }`}>
              {listingsWithRequested.length}
            </span>
          </button>

          {/* Indicator: In Progress */}
          <button
            onClick={() => setStatusFilter('in_progress')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
              statusFilter === 'in_progress'
                ? 'bg-sky-600 text-white shadow-2xs font-bold'
                : 'bg-sky-50 text-sky-900 border border-sky-200 hover:bg-sky-100'
            }`}
          >
            <span className="relative flex h-2 w-2">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                statusFilter === 'in_progress' ? 'bg-white' : 'bg-sky-400'
              }`}></span>
              <span className={`relative inline-flex rounded-full h-2 w-2 ${
                statusFilter === 'in_progress' ? 'bg-white' : 'bg-sky-500'
              }`}></span>
            </span>
            <span>В процессе</span>
            <span className={`text-[11px] px-1.5 py-0.2 rounded-md font-bold ${
              statusFilter === 'in_progress' ? 'bg-white/20 text-white' : 'bg-sky-200/70 text-sky-900'
            }`}>
              {listingsWithInProgress.length}
            </span>
          </button>

          {/* Indicator: Completed */}
          <button
            onClick={() => setStatusFilter('completed')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
              statusFilter === 'completed'
                ? 'bg-emerald-600 text-white shadow-2xs font-bold'
                : 'bg-emerald-50 text-emerald-900 border border-emerald-200 hover:bg-emerald-100'
            }`}
          >
            <CheckCircle2 className={`w-3.5 h-3.5 ${statusFilter === 'completed' ? 'text-white' : 'text-emerald-600'}`} />
            <span>Завершено</span>
            <span className={`text-[11px] px-1.5 py-0.2 rounded-md font-bold ${
              statusFilter === 'completed' ? 'bg-white/20 text-white' : 'bg-emerald-200/70 text-emerald-900'
            }`}>
              {listingsWithCompleted.length}
            </span>
          </button>

          {/* Indicator: Available */}
          <button
            onClick={() => setStatusFilter('available')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
              statusFilter === 'available'
                ? 'bg-slate-700 text-white shadow-2xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            <span>Свободно</span>
            <span className={`text-[11px] px-1.5 py-0.2 rounded-md font-bold ${
              statusFilter === 'available' ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-700'
            }`}>
              {listingsAvailable.length}
            </span>
          </button>
        </div>
      )}

      {/* Empty State: No Listings at all */}
      {myListings.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center max-w-md mx-auto">
          <Layers className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="font-bold text-slate-800 text-base">Вы пока ничего не предложили</h3>
          <p className="text-xs text-slate-500 mt-1 mb-4">
            Добавьте услугу, консультацию или полезный инструмент, чтобы другие участники могли воспользоваться ими и активировать ваши токены!
          </p>
          <button
            onClick={onOpenCreateModal}
            className="bg-teal-600 text-white text-xs font-bold px-4 py-2 rounded-xl hover:bg-teal-700 transition-colors"
          >
            Создать первое предложение
          </button>
        </div>
      ) : filteredListings.length === 0 ? (
        /* Empty State: Filter Returned No Listings */
        <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center max-w-md mx-auto">
          <p className="text-sm font-semibold text-slate-700">Нет предложений с выбранным статусом</p>
          <button
            onClick={() => setStatusFilter('all')}
            className="mt-3 text-xs text-teal-700 font-bold bg-teal-50 hover:bg-teal-100 px-3 py-1.5 rounded-xl transition-colors"
          >
            Сбросить фильтр
          </button>
        </div>
      ) : (
        /* Grid of Listings with visual deal status indicators */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredListings.map(listing => {
            const isItem = listing.type === 'item';
            
            // All deals for this listing
            const listingDeals = deals.filter(d => d.listingId === listing.id);
            const requestedDeals = listingDeals.filter(d => d.status === 'requested');
            const inProgressDeals = listingDeals.filter(d => d.status === 'in_progress');
            const completedDeals = listingDeals.filter(d => d.status === 'completed');

            const hasRequested = requestedDeals.length > 0;
            const hasInProgress = inProgressDeals.length > 0;
            const hasCompleted = completedDeals.length > 0;

            const primaryRequestedDeal = requestedDeals[0];
            const primaryInProgressDeal = inProgressDeals[0];
            const totalCompletedGlo = completedDeals.reduce((sum, d) => sum + d.priceGlo, 0);
            const latestCompletedDeal = completedDeals[0];

            return (
              <div
                key={listing.id}
                className={`bg-white rounded-2xl border p-5 shadow-2xs transition-all flex flex-col justify-between ${
                  hasRequested 
                    ? 'border-amber-300 ring-1 ring-amber-200' 
                    : hasInProgress 
                    ? 'border-sky-300 ring-1 ring-sky-200' 
                    : hasCompleted
                    ? 'border-emerald-200 hover:border-teal-300'
                    : 'border-slate-200 hover:border-teal-300'
                }`}
              >
                <div>
                  
                  {/* Top Bar: Type Badge + Visual Deal Status Indicator + Price */}
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex flex-wrap items-center gap-1.5">
                      
                      {/* Listing Type Badge */}
                      <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${
                        isItem 
                          ? 'bg-amber-50 text-amber-800 border-amber-200' 
                          : 'bg-teal-50 text-teal-800 border-teal-200'
                      }`}>
                        {isItem ? '📦 Вещь в аренду' : '🛠 Услуга'}
                      </span>

                      {/* Primary Visual Deal Status Indicator Badge */}
                      {hasRequested && (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300 animate-pulse">
                          <Clock className="w-3 h-3 text-amber-700" />
                          <span>Ожидание ({requestedDeals.length})</span>
                        </span>
                      )}

                      {hasInProgress && (
                        <span className="inline-flex items-center gap-1.5 text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-sky-100 text-sky-900 border border-sky-300">
                          <span className="relative flex h-1.5 w-1.5">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-sky-600"></span>
                          </span>
                          <span>В процессе ({inProgressDeals.length})</span>
                        </span>
                      )}

                      {!hasRequested && !hasInProgress && hasCompleted && (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 border border-emerald-300">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          <span>Завершено ({completedDeals.length})</span>
                        </span>
                      )}

                      {!hasRequested && !hasInProgress && !hasCompleted && (
                        <span className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                          <span>Свободно</span>
                        </span>
                      )}
                    </div>

                    {/* Price */}
                    <div className="text-right shrink-0">
                      <span className="text-sm font-black text-emerald-700 font-['Space_Grotesk']">
                        {listing.priceGlo} GLO
                      </span>
                      <span className="text-[10px] text-slate-400 block">
                        / {listing.durationUnit}
                      </span>
                    </div>
                  </div>

                  {/* Photo / Video preview */}
                  {listing.media && listing.media.length > 0 && (
                    <ListingThumb media={listing.media} className="aspect-video w-full max-w-xs rounded-xl mb-3" />
                  )}

                  {/* Title & Description */}
                  <h3 className="font-bold text-slate-900 text-sm sm:text-base leading-snug">
                    {listing.title}
                  </h3>

                  <p className="text-xs text-slate-500 mt-1.5 line-clamp-2">
                    {listing.description}
                  </p>

                  <div className="flex items-center gap-3 mt-2.5 text-xs text-slate-400">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      {listing.location}
                    </span>
                    <span>•</span>
                    <span className="text-slate-600 font-medium">
                      Всего использований: <strong className="text-slate-900">{listing.usageCount}</strong>
                    </span>
                  </div>

                  {/* ============================================================ */}
                  {/* VISUAL INDICATORS OF DEAL STATUS ON CARD                     */}
                  {/* ============================================================ */}

                  {/* 1. INDICATOR: ОЖИДАНИЕ (Requested Deal) */}
                  {hasRequested && primaryRequestedDeal && (
                    <div className="mt-3.5 p-3 bg-gradient-to-r from-amber-50/90 to-amber-50/40 border border-amber-300/80 rounded-xl space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <span className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-900">
                          <Clock className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                          <span>Ожидание подтверждения</span>
                        </span>
                        <span className="text-xs font-bold text-amber-800 bg-amber-200/70 px-2 py-0.5 rounded-md shrink-0">
                          +{primaryRequestedDeal.priceGlo} GLO в холде
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-xs text-slate-700">
                        <img
                          src={primaryRequestedDeal.buyerAvatar}
                          alt={primaryRequestedDeal.buyerName}
                          className="w-5 h-5 rounded-full object-cover ring-1 ring-amber-300"
                        />
                        <span>
                          Запрос от: <strong className="text-slate-900">{primaryRequestedDeal.buyerName}</strong>
                        </span>
                        <span className="text-slate-400 text-[11px]">
                          ({primaryRequestedDeal.requestedDate})
                        </span>
                      </div>

                      {primaryRequestedDeal.note && (
                        <p className="text-[11px] text-amber-950 bg-white/80 p-2 rounded-lg italic border border-amber-200/60 leading-tight">
                          «{primaryRequestedDeal.note}»
                        </p>
                      )}

                      <div className="pt-1 flex items-center justify-between gap-2">
                        <span className="text-[11px] text-amber-800/90">
                          Примите, чтобы начать сделку
                        </span>
                        <button
                          onClick={() => acceptDeal(primaryRequestedDeal.id)}
                          className="bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1 shadow-2xs"
                        >
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                          <span>Принять запрос</span>
                        </button>
                      </div>
                    </div>
                  )}

                  {/* 2. INDICATOR: В ПРОЦЕССЕ (In-Progress Deal) */}
                  {hasInProgress && primaryInProgressDeal && (
                    <div className="mt-3.5 p-3 bg-gradient-to-r from-sky-50/90 to-sky-50/40 border border-sky-300/80 rounded-xl space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <span className="inline-flex items-center gap-1.5 text-xs font-bold text-sky-950">
                          <span className="relative flex h-2 w-2 shrink-0">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-2 w-2 bg-sky-500"></span>
                          </span>
                          <span>В процессе использования</span>
                        </span>
                        <span className="text-xs font-bold text-sky-800 bg-sky-200/70 px-2 py-0.5 rounded-md shrink-0">
                          +{primaryInProgressDeal.priceGlo} GLO ожидается
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-xs text-slate-700">
                        <img
                          src={primaryInProgressDeal.buyerAvatar}
                          alt={primaryInProgressDeal.buyerName}
                          className="w-5 h-5 rounded-full object-cover ring-1 ring-sky-300"
                        />
                        <span>
                          Пользуется: <strong className="text-slate-900">{primaryInProgressDeal.buyerName}</strong>
                        </span>
                        <span className="text-slate-400 text-[11px]">
                          (с {primaryInProgressDeal.requestedDate})
                        </span>
                      </div>

                      <div className="pt-1 flex items-center justify-between gap-2">
                        <span className="text-[11px] text-sky-800">
                          Токены станут активными при завершении
                        </span>
                        <button
                          onClick={() => confirmDealCompletion(primaryInProgressDeal.id)}
                          className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1 shadow-2xs"
                          title="Подтвердить завершение и активировать токены"
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>Подтвердить</span>
                        </button>
                      </div>
                    </div>
                  )}

                  {/* 3. INDICATOR: ЗАВЕРШЕНО (Completed Deals) */}
                  {hasCompleted && (
                    <div className={`p-2.5 rounded-xl border text-xs ${
                      hasRequested || hasInProgress 
                        ? 'mt-2 bg-emerald-50/40 border-emerald-200/60 text-emerald-900' 
                        : 'mt-3.5 bg-gradient-to-r from-emerald-50/90 to-emerald-50/40 border-emerald-300/80 text-emerald-950'
                    }`}>
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-bold flex items-center gap-1.5 text-emerald-900">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>Завершено: {completedDeals.length} {getDealsDeclension(completedDeals.length)}</span>
                        </span>
                        <span className="font-bold text-emerald-800 bg-emerald-200/70 px-2 py-0.5 rounded-md">
                          +{totalCompletedGlo} GLO активировано
                        </span>
                      </div>

                      {latestCompletedDeal && (
                        <div className="text-[11px] text-emerald-800/90 mt-1 flex items-center justify-between">
                          <span>Последняя сделка: {latestCompletedDeal.buyerName}</span>
                          <span className="text-slate-400 text-[10px]">
                            {latestCompletedDeal.completedDate || latestCompletedDeal.requestedDate}
                          </span>
                        </div>
                      )}
                    </div>
                  )}

                  {/* 4. INDICATOR: СВОБОДНО (No active deals) */}
                  {!hasRequested && !hasInProgress && !hasCompleted && (
                    <div className="mt-3.5 p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-500 flex items-center justify-between">
                      <span className="flex items-center gap-1.5 font-medium">
                        <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                        <span>Нет активных сделок</span>
                      </span>
                      <span className="text-[11px] text-slate-400">
                        Доступно в каталоге
                      </span>
                    </div>
                  )}

                </div>

                {/* Card Footer: Publish date + Action buttons */}
                <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between gap-2">
                  <span className="text-[11px] text-slate-400">
                    Опубликовано: {listing.createdAt}
                  </span>

                  <div className="flex items-center gap-2">
                    {listingDeals.length > 0 && (
                      <button
                        onClick={() => setActiveTab('deals')}
                        className="text-xs font-semibold text-slate-600 hover:text-slate-900 flex items-center gap-1 bg-slate-100 hover:bg-slate-200 px-2.5 py-1.5 rounded-xl transition-colors"
                        title="Открыть раздел сделок"
                      >
                        <Handshake className="w-3.5 h-3.5 text-slate-500" />
                        <span>Сделки ({listingDeals.length})</span>
                      </button>
                    )}

                    <button
                      onClick={() => onSelectListing(listing)}
                      className="text-xs font-bold text-teal-700 hover:text-teal-800 flex items-center gap-1 bg-teal-50 hover:bg-teal-100 px-3 py-1.5 rounded-xl transition-colors"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Карточка</span>
                    </button>
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
